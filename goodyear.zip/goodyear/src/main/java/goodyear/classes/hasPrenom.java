package goodyear.classes;

public interface hasPrenom {
    public String getPrenom();
}
