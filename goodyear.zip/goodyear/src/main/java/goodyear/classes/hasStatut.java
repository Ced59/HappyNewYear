package goodyear.classes;

public interface hasStatut {
    String getStatut();
}
