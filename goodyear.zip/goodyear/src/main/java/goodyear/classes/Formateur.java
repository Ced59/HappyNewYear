package goodyear.classes;


public class Formateur extends Personne {

    public Formateur(String prenom, String statut) {
        super(prenom);
        this.statut = statut;
    }
}